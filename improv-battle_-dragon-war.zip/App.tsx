import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, Terminal, Flame, Play, Square, Loader2 } from 'lucide-react';

import { ConnectionState, TranscriptionItem } from './types';
import { SYSTEM_INSTRUCTION, MODEL_NAME } from './constants';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from './utils/audio-utils';
import { AudioVisualizer } from './components/AudioVisualizer';

const App: React.FC = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [transcriptions, setTranscriptions] = useState<TranscriptionItem[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Audio Context Refs
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const inputAnalyserRef = useRef<AnalyserNode | null>(null);
  const outputAnalyserRef = useRef<AnalyserNode | null>(null);
  
  // Stream & Session Refs
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<any>(null); // To store the resolved session object
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Transcription Buffers
  const currentInputTransRef = useRef<string>('');
  const currentOutputTransRef = useRef<string>('');

  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [transcriptions]);

  const disconnect = useCallback(() => {
    // Stop Microphone
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    // Close Audio Contexts
    if (inputContextRef.current) {
      inputContextRef.current.close();
      inputContextRef.current = null;
    }
    if (outputContextRef.current) {
      outputContextRef.current.close();
      outputContextRef.current = null;
    }

    // Close Session (no explicit close method in new SDK for session object, but we stop sending)
    // We can signal a close via the internal client if we had access, but for now we just reset state.
    // The WebSocket will close when the page unloads or we can drop the reference.
    sessionRef.current = null;
    
    // Stop all playing audio
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();

    setConnectionState(ConnectionState.DISCONNECTED);
  }, []);

  const connect = async () => {
    try {
      setConnectionState(ConnectionState.CONNECTING);
      setErrorMsg(null);

      // Initialize Audio Contexts
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputContextRef.current = inputCtx;
      outputContextRef.current = outputCtx;

      // Analysers for Visuals
      const inAnalyser = inputCtx.createAnalyser();
      const outAnalyser = outputCtx.createAnalyser();
      inAnalyser.fftSize = 64;
      outAnalyser.fftSize = 64;
      inputAnalyserRef.current = inAnalyser;
      outputAnalyserRef.current = outAnalyser;

      // Connect Output Node
      const outputGain = outputCtx.createGain();
      outputGain.connect(outAnalyser);
      outAnalyser.connect(outputCtx.destination);

      // Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Connect to Gemini Live
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: SYSTEM_INSTRUCTION,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log("Session Opened");
            setConnectionState(ConnectionState.CONNECTED);
            
            // Setup Input Processing
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            source.connect(inAnalyser);
            inAnalyser.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);

            scriptProcessor.onaudioprocess = (e) => {
              if (!inputContextRef.current) return; // Stop processing if disconnected
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              
              sessionPromise.then((session) => {
                sessionRef.current = session;
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
          },
          onmessage: async (message: LiveServerMessage) => {
             // Handle Transcriptions
             if (message.serverContent?.outputTranscription) {
                const text = message.serverContent.outputTranscription.text;
                currentOutputTransRef.current += text;
              } else if (message.serverContent?.inputTranscription) {
                const text = message.serverContent.inputTranscription.text;
                currentInputTransRef.current += text;
              }

              if (message.serverContent?.turnComplete) {
                const userText = currentInputTransRef.current;
                const modelText = currentOutputTransRef.current;
                
                if (userText.trim()) {
                   setTranscriptions(prev => [...prev, {
                     id: Date.now().toString() + '-user',
                     sender: 'user',
                     text: userText,
                     timestamp: Date.now()
                   }]);
                }
                if (modelText.trim()) {
                   setTranscriptions(prev => [...prev, {
                     id: Date.now().toString() + '-model',
                     sender: 'model',
                     text: modelText,
                     timestamp: Date.now()
                   }]);
                }

                currentInputTransRef.current = '';
                currentOutputTransRef.current = '';
              }

              // Handle Audio Output
              const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (base64Audio && outputContextRef.current) {
                const ctx = outputContextRef.current;
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                
                const audioBuffer = await decodeAudioData(
                  base64ToUint8Array(base64Audio),
                  ctx,
                  24000,
                  1
                );

                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(outputGain);
                
                source.addEventListener('ended', () => {
                  sourcesRef.current.delete(source);
                });

                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                sourcesRef.current.add(source);
              }

              // Handle Interruptions
              if (message.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => s.stop());
                sourcesRef.current.clear();
                nextStartTimeRef.current = 0;
                // Also clear pending transcriptions on interrupt
                currentOutputTransRef.current = ''; 
              }
          },
          onclose: () => {
            console.log("Session Closed");
            disconnect();
          },
          onerror: (err) => {
            console.error("Session Error", err);
            setErrorMsg("Connection error occurred. Please try again.");
            disconnect();
          }
        }
      });

    } catch (e: any) {
      console.error(e);
      setErrorMsg(e.message || "Failed to connect to audio or API.");
      setConnectionState(ConnectionState.ERROR);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-orange-100 flex flex-col items-center p-4 sm:p-8">
      
      {/* Header */}
      <header className="mb-8 text-center space-y-2">
        <h1 className="text-4xl sm:text-6xl font-black fantasy-font text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 drop-shadow-sm">
          DRAGON WAR
        </h1>
        <p className="text-orange-300/80 text-lg sm:text-xl fantasy-font tracking-widest">
          IMPROV BATTLE EDITION
        </p>
      </header>

      {/* Main Stage */}
      <main className="w-full max-w-3xl flex-1 flex flex-col gap-6">
        
        {/* Status Area */}
        <div className="bg-neutral-900/50 border border-orange-900/40 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-50"></div>
          
          <div className="flex justify-between items-center mb-4">
             <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${connectionState === ConnectionState.CONNECTED ? 'bg-green-500 animate-pulse' : 'bg-red-900'}`}></div>
                <span className="text-sm font-bold tracking-wider text-neutral-400">
                  {connectionState === ConnectionState.CONNECTED ? 'HOST CONNECTED' : 'OFFLINE'}
                </span>
             </div>
             {connectionState === ConnectionState.CONNECTED && (
               <div className="flex items-center gap-1 text-red-400 text-xs uppercase animate-pulse">
                 <Mic size={12} /> Live
               </div>
             )}
          </div>

          {/* Controls */}
          <div className="flex flex-col items-center justify-center gap-6 py-4">
             {connectionState === ConnectionState.DISCONNECTED || connectionState === ConnectionState.ERROR ? (
                <button 
                  onClick={connect}
                  className="group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-red-900 font-lg rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-900 hover:bg-red-800"
                >
                  <Play className="w-6 h-6 mr-2 fill-current" />
                  START SHOW
                  <div className="absolute inset-0 rounded-full ring-2 ring-white/20 group-hover:ring-white/40 animate-pulse"></div>
                </button>
             ) : connectionState === ConnectionState.CONNECTING ? (
               <button disabled className="px-8 py-4 bg-neutral-800 text-neutral-400 rounded-full flex items-center">
                 <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                 Summoning Host...
               </button>
             ) : (
                <div className="flex flex-col items-center gap-4 w-full">
                  <div className="flex gap-4 w-full">
                    {/* Visualizers */}
                    <div className="flex-1 relative">
                       <p className="absolute top-2 left-2 text-xs text-red-500 font-bold uppercase z-10">You</p>
                       <AudioVisualizer analyser={inputAnalyserRef.current} isActive={true} />
                    </div>
                    <div className="flex-1 relative">
                        <p className="absolute top-2 left-2 text-xs text-orange-500 font-bold uppercase z-10">Dragon War</p>
                        <AudioVisualizer analyser={outputAnalyserRef.current} isActive={true} />
                    </div>
                  </div>

                  <button 
                    onClick={disconnect}
                    className="mt-4 px-6 py-2 bg-neutral-800 border border-red-900/50 hover:bg-red-900/20 text-red-400 rounded-lg flex items-center transition-colors text-sm"
                  >
                    <Square className="w-4 h-4 mr-2 fill-current" />
                    End Show
                  </button>
                </div>
             )}
          </div>

          {errorMsg && (
            <div className="mt-4 p-3 bg-red-950/50 border border-red-900 text-red-200 text-sm rounded text-center">
              {errorMsg}
            </div>
          )}
        </div>

        {/* Transcript / Game Log */}
        <div className="flex-1 min-h-[300px] bg-neutral-900/30 border border-neutral-800 rounded-xl p-4 flex flex-col relative">
           <div className="absolute top-0 right-0 p-2 opacity-20">
             <Flame size={120} />
           </div>
           
           <div className="flex items-center gap-2 mb-4 text-neutral-500 border-b border-neutral-800 pb-2">
             <Terminal size={16} />
             <span className="text-xs uppercase tracking-widest font-semibold">Game Log</span>
           </div>

           <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-neutral-700 scrollbar-track-transparent">
              {transcriptions.length === 0 && (
                <div className="text-neutral-600 text-center italic mt-10">
                  {connectionState === ConnectionState.CONNECTED 
                    ? "Listening for audio..." 
                    : "Connect to begin the Improv Battle..."}
                </div>
              )}
              
              {transcriptions.map((t) => (
                <div key={t.id} className={`flex ${t.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div 
                    className={`max-w-[80%] p-3 rounded-lg text-sm leading-relaxed ${
                      t.sender === 'user' 
                        ? 'bg-neutral-800 text-neutral-200 rounded-tr-none' 
                        : 'bg-red-950/40 text-orange-100 border border-red-900/30 rounded-tl-none'
                    }`}
                  >
                    <div className="mb-1 text-[10px] uppercase font-bold opacity-50">
                      {t.sender === 'user' ? 'Challenger' : 'Dragon War'}
                    </div>
                    {t.text}
                  </div>
                </div>
              ))}
           </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="mt-8 text-neutral-600 text-xs text-center max-w-md">
        <p>Powered by Google Gemini Live API. Speak clearly into your microphone.</p>
        <p className="mt-1">Say "End Scene" when finished with your improv round.</p>
      </footer>

    </div>
  );
};

export default App;
